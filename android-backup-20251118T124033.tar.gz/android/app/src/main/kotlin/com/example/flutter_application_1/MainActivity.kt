// Kotlin MainActivity removed. Using Java MainActivity under
// android/app/src/main/java/... instead. Left this file as a
// harmless placeholder to avoid accidental restores.

